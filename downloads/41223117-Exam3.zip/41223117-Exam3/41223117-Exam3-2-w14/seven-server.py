# pip install websocket-server
import threading
import socket
import json
from websocket_server import WebsocketServer
from controller import Supervisor

class SevenSegmentController:
    def __init__(self, supervisor, color_on, color_off):
        self.supervisor = supervisor
        # 擴充到 8 個顯示器，DEF 請在 world 中設好
        self.digit_segments = [
            ["seven_segment_a1", "seven_segment_b1", "seven_segment_c1", "seven_segment_d1", "seven_segment_e1", "seven_segment_f1", "seven_segment_g1"],  # index 0
            ["seven_segment_a2", "seven_segment_b2", "seven_segment_c2", "seven_segment_d2", "seven_segment_e2", "seven_segment_f2", "seven_segment_g2"],  # index 1
            ["seven_segment_a3", "seven_segment_b3", "seven_segment_c3", "seven_segment_d3", "seven_segment_e3", "seven_segment_f3", "seven_segment_g3"],  # index 2 (3號位)
            ["seven_segment_a4", "seven_segment_b4", "seven_segment_c4", "seven_segment_d4", "seven_segment_e4", "seven_segment_f4", "seven_segment_g4"],
            ["seven_segment_a5", "seven_segment_b5", "seven_segment_c5", "seven_segment_d5", "seven_segment_e5", "seven_segment_f5", "seven_segment_g5"],
            ["seven_segment_a6", "seven_segment_b6", "seven_segment_c6", "seven_segment_d6", "seven_segment_e6", "seven_segment_f6", "seven_segment_g6"],
            ["seven_segment_a7", "seven_segment_b7", "seven_segment_c7", "seven_segment_d7", "seven_segment_e7", "seven_segment_f7", "seven_segment_g7"],
            ["seven_segment_a8", "seven_segment_b8", "seven_segment_c8", "seven_segment_d8", "seven_segment_e8", "seven_segment_f8", "seven_segment_g8"],
        ]
        self.segment_patterns = {
            0: [1,1,1,1,1,1,0],
            1: [0,1,1,0,0,0,0],
            2: [1,1,0,1,1,0,1],
            3: [1,1,1,1,0,0,1],
            4: [0,1,1,0,0,1,1],
            5: [1,0,1,1,0,1,1],
            6: [1,0,1,1,1,1,1],
            7: [1,1,1,0,0,0,0],
            8: [1,1,1,1,1,1,1],
            9: [1,1,1,1,0,1,1]
        }
        self.color_on = color_on
        self.color_off = color_off
        self.segment_nodes = []
        for digit in self.digit_segments:
            digit_fields = []
            for segment_def in digit:
                shape_node = self.supervisor.getFromDef(segment_def)
                if shape_node is None:
                    print(f"[ERROR] 找不到 DEF 名稱：{segment_def}")
                    continue
                try:
                    appearance_field = shape_node.getField("appearance")
                    appearance_node = appearance_field.getSFNode()
                    material_field = appearance_node.getField("material")
                    material_node = material_field.getSFNode()
                    diffuse_color_field = material_node.getField("diffuseColor")
                    digit_fields.append(diffuse_color_field)
                except Exception as e:
                    print(f"[ERROR] 處理 {segment_def} 時出錯: {e}")
            self.segment_nodes.append(digit_fields)
        print(f"[DEBUG] segment_nodes 結構: {[len(d) for d in self.segment_nodes]}")

        # 初始化讓3號位永遠顯示1
        self.set_digit(2, 1)

    def set_digit(self, digit_index, value):
        pattern = self.segment_patterns[value]
        for i, state in enumerate(pattern):
            color = self.color_on if state else self.color_off
            try:
                self.segment_nodes[digit_index][i].setSFVec3f(color)
            except Exception as e:
                print(f"[ERROR] setSFVec3f 失敗: digit={digit_index}, seg={i}, error={e}")

    def display_number(self, number):
        if not (0 <= number <= 999):
            print("Error: Number out of range (0-999)")
            return
        hundreds = number // 100
        tens = (number % 100) // 10
        units = number % 10
        print(f"[DEBUG] 顯示數字: {number} (百:{hundreds} 十:{tens} 個:{units})")
        # self.set_digit(2, hundreds)  # 這行註解掉，3號位永遠不動
        self.set_digit(1, tens)
        self.set_digit(0, units)

    # 額外靜態顯示指定顯示器
    def display_label_digits(self, digit_map):
        """
        digit_map: dict, key=顯示器編號(3~8), value=顯示的數字
        """
        for digit_num, value in digit_map.items():
            # 顯示器3-8, digit_segments索引為2~7
            seg_index = digit_num - 1  # seven_segment_a3~g3 對應 index=2, ... a8~g8對應index=7
            if 0 <= seg_index < len(self.segment_nodes):
                self.set_digit(seg_index, value)
            else:
                print(f"[ERROR] 沒有這個顯示器: {digit_num}")

class WSSevenSegmentServer:
    def __init__(self, ipv6, port):
        self.up_sequence = [17, 50, 26]    # S（上一個）
        self.down_sequence = [17, 50, 26]  # W（下一個）
        self.current_number = 17
        self.supervisor = Supervisor()
        self.timestep = int(self.supervisor.getBasicTimeStep())
        self.controller = SevenSegmentController(self.supervisor, [0,1,0], [0,0,0])
        self.controller.display_number(self.current_number)

        # 額外靜態顯示（4~8，不包括3，3已經被上面初始化成1）
        label_map = {4:3, 5:2, 6:2, 7:1, 8:4}
        self.controller.display_label_digits(label_map)

        class IPv6WebsocketServer(WebsocketServer):
            def __init__(s, host, port):
                s.address_family = socket.AF_INET6
                super().__init__(host=host, port=port)
        self.wss = IPv6WebsocketServer(host=ipv6, port=port)
        self.wss.set_fn_message_received(self.on_message)

    def on_message(self, client, server, message):
        print(f"[INFO] 原始收到訊息：{repr(message)}")
        # 支援 JSON 和純字串
        try:
            data = json.loads(message)
            if isinstance(data, dict):
                msg = str(data.get('cmd', '')).strip().upper()
            else:
                msg = str(data).strip().upper()
        except Exception:
            msg = str(message).strip().upper()
        print(f"[INFO] 處理後訊息：{msg}")
        try:
            if msg == "W":
                # W 現在改成 down_sequence
                if self.current_number in self.down_sequence:
                    idx = self.down_sequence.index(self.current_number)
                    next_idx = (idx + 1) % len(self.down_sequence)
                else:
                    next_idx = 0
                self.current_number = self.down_sequence[next_idx]
                self.controller.display_number(self.current_number)
                print(f"[INFO] W（下一個）切換到：{self.current_number}")
                server.send_message(client, f"W切換到: {self.current_number}")
            elif msg == "S":
                # S 現在改成 up_sequence
                if self.current_number in self.up_sequence:
                    idx = self.up_sequence.index(self.current_number)
                    next_idx = (idx + 1) % len(self.up_sequence)
                else:
                    next_idx = 0
                self.current_number = self.up_sequence[next_idx]
                self.controller.display_number(self.current_number)
                print(f"[INFO] S（上一個）切換到：{self.current_number}")
                server.send_message(client, f"S切換到: {self.current_number}")
            else:
                print("[WARN] 收到未處理指令")
                server.send_message(client, f"未處理的訊息: {message}")
        except Exception as e:
            print(f"[ERROR] 處理訊息時發生錯誤: {e}")
            server.send_message(client, f"錯誤: {e}")

    def run_wss(self):
        print(f"[INFO] WebSocket server started on [{self.wss.host}]:{self.wss.port}, waiting for commands...")
        self.wss.run_forever()

    def run_supervisor(self):
        print("[INFO] Supervisor 迴圈啟動")
        while self.supervisor.step(self.timestep) != -1:
            pass

    def run(self):
        print("[INFO] 伺服器主程式已啟動")
        t1 = threading.Thread(target=self.run_wss, daemon=True)
        t2 = threading.Thread(target=self.run_supervisor, daemon=True)
        t1.start()
        t2.start()
        try:
            while True:
                pass
        except KeyboardInterrupt:
            print("[INFO] 結束伺服器...")

if __name__ == "__main__":
    ipv6 = "2001:288:6004:17:fff1:cd25:0:a023"   # 換成你的 IPv6
    port = 8081
    WSSevenSegmentServer(ipv6, port).run()
